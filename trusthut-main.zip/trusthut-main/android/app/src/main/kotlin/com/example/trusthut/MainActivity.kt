package com.example.trusthut

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
